/*Desarrollado por 
Natalia Gaona Salamanca
Laura Sofia Jimenez Ballen
Esteban Alberto Rojas Molina

Referencias de codigo: // Mariela Curiel
Proyecto Primera Entrga SOP*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include "libro.h"
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#define TAMMENSAJE 10
#define TAMBUF 5

libro BUFFER[TAMBUF]; // buffer donde se pondrá la informacion
int precep=0, psoli=0;
sem_t s, espacios, elementos; 

void *take(libro *);
void *put(libro *);

    /*Nombre: take 

    Entradas: La struct del libro

    Objetivo: Quita la información del buffer, pero además apaga los semaforos correspondientes 
    para que no accedan a lo que no deben acceder y así el hilo ya tiene la información que tenía el buffer

    Salida: El hilo con los datos del buffer el cual se encargara de ir colocando los libros con los cambios en la BD Actualizada*/
void *take(libro *e) {

  libro temp,*pe;

  pe = e; //pe ahora apunta al buffer
  int i=0;

  for (;;) {
    
    sem_wait(&elementos);
    sem_wait(&s);
    memcpy(&temp, &pe[precep], sizeof(libro));
    pe[precep].isbn = 0; // para indicar que la posición está vacia
    precep= (precep + 1) % TAMBUF;
    if (temp.isbn == -1) { // el ultimo elemento
      sem_post(&s);
      sem_post(&espacios);
      break;
    } else {
      // Se imprime el elemento que se toma del buffer
      printf (" Thread leyo %s %d %d\n", temp.nombreLibro, temp.isbn, temp.operacion);
      sem_post(&s);
      sem_post(&espacios);
    }  
    
  }
  printf("thread consumidor termina\n");
  pthread_exit(NULL);
  
}  
/*  Nombre: put 

    Entradas: La struct del libro

    Objetivo: Pone las cosas necesarias en el buffer, pero además apaga los semaforos correspondientes 
    para que no accedan a lo que no deben acceder y así después puede acceder a la función take y poder ir colocando 
    la informacion de la solicitud que llega en el buffer

    Salida: De salida se tiene el buffer con la informacion que llega en cada solicitud*/
void *put(libro *e) {
      sem_wait(&espacios);
      sem_wait(&s);
      if (BUFFER[psoli].isbn == 0) {
        memcpy(&BUFFER[psoli], e, sizeof(libro));
        psoli = (psoli + 1) % TAMBUF;
      }
      sem_post(&s);
      sem_post(&elementos);
}  

/*
    Nombre: leerBaseDatos 

    Entradas: El archivo de la base de datos, La posicion del arreglo en el que se ira guardando la informacion de cada libro que se lee en el arquivo, la estructura de datos. 

    Objetivo: Separar el archivo de la base de datos con tokens para que se pueda guardar en la struct de datos y de libro y así guardar ese archivo en ese struct. 

    Salida: Un arreglo lleno de las struct de datosGeneralesBD con la info de la base de datos. 
*/
void leerBaseDatos(char *archivo, int *ubiLibro, datosGeneralesBD *datos){
    
    FILE *fd;
    char lineaToken[256];
    char lineaToken2[256];

    fd = fopen(archivo, "r");

    while(!feof(fd)){
        fgets(lineaToken, sizeof(lineaToken), fd);

        char *tok;
        tok = strtok(lineaToken, ",");
   
        strcpy(datos[*ubiLibro].nombre,tok);
        tok = strtok(NULL, ",");
        datos[*ubiLibro].isbn = atoi(tok);
        tok = strtok(NULL, ",");
        datos[*ubiLibro].cant = atoi(tok);
            
        for(int j =0 ; j< datos[*ubiLibro].cant;j++){

            fgets(lineaToken2, sizeof(lineaToken2), fd);
            char *tok2;
            tok2 = strtok(lineaToken2, ",");
            int aux=0;

            while(tok2!=NULL){
              
                if(aux==0){
                    datos[*ubiLibro].datosBD[j].idlibro = atoi(tok2);
                }
                aux++;
                tok2 = strtok(NULL, ",-");
                if(aux==1){
                    datos[*ubiLibro].datosBD[j].operacion = tok2[0];
                }
                if(aux==2){
                    datos[*ubiLibro].datosBD[j].fecha.dia = atoi(tok2);
                }  
                if(aux==3){
                    datos[*ubiLibro].datosBD[j].fecha.mes = atoi(tok2);
                }
                if(aux==4){
                    datos[*ubiLibro].datosBD[j].fecha.anio = atoi(tok2);
                }  
            
            }
        }
        *ubiLibro = *ubiLibro + 1;
    }
    

}

/*
    Nombre: makeFile 

    Entradas: Un archivo en donde se gurdará la base de datos actualizada, Apuntador de un arreglo de structs de la base de datos y La posicion del arreglo de donde se va a ir actualizando cada libro en la nueva BD. 

    Objetivo: Guardar toda la info de la struct de la base de datos en un arhivo para que este se actualice con la información almacenda. 

    Salida: El archivo actualizado. 
*/
void makeFile(char *archivoSalida, datosGeneralesBD *datos, int *ubiLibro){
    FILE *fp;
    fp = fopen(archivoSalida,"w");
    if(fp == NULL){
        perror("Problemas al abrir el archivo");
        exit(0);
    }

    for(int i=0;i<*ubiLibro;i++){
        fprintf(fp, "%s %d %d\n", datos[i].nombre,datos[i].isbn,datos[i].cant);
        for(int j=0;j<datos[i].cant;j++){
            fprintf(fp, "%d %c %d%d%d\n", datos[i].datosBD[j].idlibro,datos[i].datosBD[j].operacion,datos[i].datosBD[j].fecha.dia,datos[i].datosBD[j].fecha.mes,datos[i].datosBD[j].fecha.anio);
        }
    }

    fclose(fp);

}

/*
    Nombre: main

    Entradas:./receptor –p pipeReceptor –f filedatos –s filesalida

    Objetivo: Ejecutar las demás funciones, recibir la información del Solicitante y crear el hlo

    Salida: Funcionamiento general del programa, con una ejecucion exitosa o erronea. 
*/
int main(int argc,char  *argv[]){

    if(argc !=7){
        perror("No se pasaron los argumentos necesarios o son argumentos incorrectos\n ");
        printf("$ ./receptor –p pipeReceptor –f filedatos –s filesalida\n");
        exit(0);
    }

    int fd, fd1, pid, bytes, creado=0, res, ubiLibro=0;
    libro libroSolicitante;
    pthread_t thread1;
    datosGeneralesBD *datos = (datosGeneralesBD*) malloc(100*sizeof(datosGeneralesBD)); 

    mode_t fifo_mode = S_IRUSR | S_IWUSR;

    //Inicializan semaforos
    sem_init(&s, 0, 1);
    sem_init(&espacios, 0, TAMBUF);
    sem_init(&elementos, 0, 0);
    //Iniciliza buffer
    for (int i=0; i < TAMBUF; i++) BUFFER[i].isbn = 0;

    // Creación del hilo consumidor

    pthread_create(&thread1, NULL, (void*) take, (void*)BUFFER); 

    

    leerBaseDatos(argv[4], &ubiLibro, datos);
    printf("----------Se lee base de datos---------- \n");
    printf("----------Esperando Solicitud .........\n");
    /*for(int i=0; i<ubiLibro; i++){
        printf("Nombre : %s , ISBN : %i , #Ejemplares: %i \n ", datos[i].nombre, datos[i].isbn, datos[i].cant);
        for(int j =0; j<datos[i].cant;j++){
            printf("IDLibro: %i ,Operacion: %c , Fecha: %i / %i / %i \n ",datos[i].datosBD[j].idlibro,  datos[i].datosBD[j].operacion,  datos[i].datosBD[j].fecha.dia, datos[i].datosBD[j].fecha.mes, datos[i].datosBD[j].fecha.anio);
        }
    }*/

    //printf("Se crea Pipe para obtener solicitud Pipe: %s \n ", argv[2]);
    
    unlink(argv[2]);
    if (mkfifo (argv[2], fifo_mode) == -1) {
        perror("receptor  mkfifo");
        exit(0);
    }
    //printf("Se pudo abrir el Pipe Receptor Pipe: %s\n", argv[2]);
    
    if ((fd = open(argv[2], O_RDONLY)) == -1){
        perror("No se pudo abrir el pipe, hubo un error");
        exit(0); 
    }

    //printf("Se logro abrir el Pipe: %s \n",argv[2]);

    
    
    do{
        //se lee la solicituda que esta mandando el archivo PS
        bytes = read(fd, &libroSolicitante, sizeof(libroSolicitante));  
        if(bytes==0){
            printf("Ya se termino el proceso, esperaremos por otra solicitud");
            sleep(20);
            bytes=read(fd,&libroSolicitante, sizeof(libroSolicitante));
            if(bytes==0){
                break;
            }
        }

        if(bytes==-1){
            perror("Error en el proceso de lectura");
            exit(0);
        }
        printf("\n");
        printf("..........Se esta leyendo la solicitud.............\n");
        /*printf("Lo que llego en la solicitud fue lo siguiente: \n ");
        printf("\tSolicitud: %c\n", libroSolicitante.operacion);
        printf("\tNombre: %s\n", libroSolicitante.nombreLibro);
        printf("\tISBN: %d\n", libroSolicitante.isbn);
        printf("\tPipe: %s\n", libroSolicitante.segundopipe);*/
  
        
        do{ 
            if((fd1 = open(libroSolicitante.segundopipe, O_WRONLY | O_NONBLOCK)) == -1) {
                perror(" Receptor Abriendo el segundo pipe. Se volvera a intentar ");
                sleep(2);
            } else {
                creado = 1; 
            }
        } while (creado == 0);

        time_t time_fecha= time(NULL);
        struct tm tm = *localtime(&time_fecha);

        
        switch(libroSolicitante.operacion){
           
            case 'D':
                //printf("entro a funcion devolver\n");
                creado = 0;
                do { 
                    if ((fd1 = open(libroSolicitante.segundopipe, O_WRONLY | O_NONBLOCK )) == -1) {
                        perror(" Receptor Abriendo el segundo pipe. Se volvera a intentar ");
                        sleep(2);
                    } else creado = 1; 
                } while (creado == 0);

                int encontrado = 0;
                
                int estaBD=0;
                for(int i=0;i<ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn){
                        estaBD=1;
                    }
                }
                printf("\n");
                printf("-------------El Receptor esta enviando una respuesta . . .\n");
                for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn){
                        for(int j=0;j<datos[i].cant;j++){
                            if(datos[i].datosBD[j].operacion == 'P' && encontrado==0){
                                encontrado=1;
                                datos[i].datosBD[j].operacion = 'D';
                                datos[i].datosBD[j].fecha.dia = tm.tm_mday;
                                datos[i].datosBD[j].fecha.mes = (tm.tm_mon+1);
                                datos[i].datosBD[j].fecha.anio = (tm.tm_year + 1900);
                            }
                        }
                    }
                }
                if(estaBD==0){
                        printf("El isbn no se encontro en la BD");
                        printf("\n");
                        //exit(1);
                        write(fd1,"0",10);
                }

                /*for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn && encontrado==1){
                        printf("Estos son datos actualizados\n");
                        for(int j=0;j<datos[i].cant;j++){
                            printf("%c \n",datos[i].datosBD[j].operacion);
                            printf("%d\n",datos[i].datosBD[j].fecha.dia); 
                            printf("%d\n",datos[i].datosBD[j].fecha.mes); 
                            printf("%d\n",datos[i].datosBD[j].fecha.anio); 
                        }
                        printf("----------------------\n");
                    }
                }*/
                if(estaBD!=0){
                    put(&libroSolicitante);
                    write(fd1,"1",10);
                }
                
                    
                break;
            case 'P':
                //printf("entyro a funcion pedir\n");
                creado = 0;
                do { 
                    if ((fd1 = open(libroSolicitante.segundopipe, O_WRONLY | O_NONBLOCK )) == -1) {
                        perror(" Receptor Abriendo el segundo pipe. Se volvera a intentar ");
                        sleep(2);
                    } else creado = 1; 
                } while (creado == 0);

                int encontrado2 = 0;

                int estaBD2=0;
                for(int i=0;i<ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn){
                        estaBD2=1;
                    }
                }
                
                printf("\n");
                printf("-------------El Receptor esta enviando una respuesta . . .\n");
            
                for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn ){
                        for(int j=0;j<datos[i].cant;j++){
                            if(datos[i].datosBD[j].operacion == 'D' && encontrado2==0){
                                encontrado2=1;
                                datos[i].datosBD[j].operacion = 'P';
                                datos[i].datosBD[j].fecha.dia = tm.tm_mday;
                                datos[i].datosBD[j].fecha.mes = (tm.tm_mon+1);
                                datos[i].datosBD[j].fecha.anio = (tm.tm_year + 1900);
                            }
                        }
                    }
                }
                if(estaBD2==0){
                        printf("El isbn no se encontro en la BD");
                        printf("\n");
                        //exit(1);
                        write(fd1,"0",10);
                }

                /*for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn && encontrado2==1){
                        printf("Estos son datos actualizados\n");
                        for(int j=0;j<datos[i].cant;j++){
                            printf("%c \n",datos[i].datosBD[j].operacion);
                            printf("%d\n",datos[i].datosBD[j].fecha.dia); 
                            printf("%d\n",datos[i].datosBD[j].fecha.mes); 
                            printf("%d\n",datos[i].datosBD[j].fecha.anio); 
                        }
                    }
                    printf("--------------------------");
                }*/
                if(estaBD2!=0){
                    put(&libroSolicitante);
                    write(fd1,"1",10);
                }

                break;
            case 'R':
               creado = 0;
                do { 
                    if ((fd1 = open(libroSolicitante.segundopipe, O_WRONLY | O_NONBLOCK)) == -1) {
                        perror(" Receptor Abriendo el segundo pipe. Se volvera a intentar \n");
                        sleep(2);
                    } else creado = 1; 
                } while (creado == 0);

                int encontrado3 = 0;  
                int estaBD3=0;
                for(int i=0;i<ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn){
                        estaBD3=1;
                    }
                }    
                printf("\n");                          
                printf("-------------El Receptor esta enviando una respuesta . . .\n ");

                for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn){
                        for(int j=0;j<datos[i].cant;j++){
                            if(datos[i].datosBD[j].operacion == 'P' | datos[i].datosBD[j].operacion == 'R' && encontrado3==0){
                                datos[i].datosBD[j].operacion = 'R';
                                encontrado3=1;
                                if(datos[i].datosBD[j].fecha.dia == tm.tm_mday  && 
                                    datos[i].datosBD[j].fecha.mes == (tm.tm_mon+1) &&
                                    datos[i].datosBD[j].fecha.anio == (tm.tm_year + 1900)){

                                        
                                        int dia = tm.tm_mday + 7;
                                        if(dia>30){
                                            int mes = tm.tm_mon + 2;
                                            if(mes >12){
                                                datos[i].datosBD[j].fecha.anio = datos[i].datosBD[j].fecha.anio + 1;
                                                datos[i].datosBD[j].fecha.mes = 1;
                                                datos[i].datosBD[j].fecha.dia = dia - 30;
                                            }else{
                                                datos[i].datosBD[j].fecha.mes = mes ;
                                                datos[i].datosBD[j].fecha.dia = dia - 30;
                                            }
                                        }else{
                                            datos[i].datosBD[j].fecha.dia = dia ;
                                        }
                                      
                                    }
                                else{
                                    datos[i].datosBD[j].fecha.dia = tm.tm_mday;
                                    datos[i].datosBD[j].fecha.mes = (tm.tm_mon+1);
                                    datos[i].datosBD[j].fecha.anio = (tm.tm_year + 1900);
                                    

                                }
                                
                            }
                        }
                    }
                }
                if(estaBD3==0){
                        printf("El isbn no se encontro en la BD");
                        printf("\n");
                        //exit(1);
                        write(fd1,"0",10);
                        
                }


                /*for(int i=0;i< ubiLibro;i++){
                    if(datos[i].isbn == libroSolicitante.isbn && encontrado3==1){
                        printf("Estos son datos actualizados del %d\n", datos[i].isbn);
                        for(int j=0;j<datos[i].cant;j++){
                            printf("%c \n",datos[i].datosBD[j].operacion);
                            printf("%d\n",datos[i].datosBD[j].fecha.dia); 
                            printf("%d\n",datos[i].datosBD[j].fecha.mes); 
                            printf("%d\n",datos[i].datosBD[j].fecha.anio); 
                            printf("++++++++++++++++++++++++++++\n");
                        }
                    }
                    printf("--------------------------");
                }*/
                if(estaBD3!=0){
                    put(&libroSolicitante);
                    write(fd1,"1",10);
                }
                
                


                break;
            default:
                printf("Accion no valida\n");
                break;

        }
        sleep(2);


    }while(bytes>0);

    libroSolicitante.isbn = -1;
    put(&libroSolicitante);
    
   makeFile(argv[6], datos, &ubiLibro);
   close(fd);

}
