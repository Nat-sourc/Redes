/*Desarrollado por 
Natalia Gaona Salamanca
Laura Sofia Jimenez Ballen
Esteban Alberto Rojas Molina

Referencias de codigo: // Mariela Curiel

Proyecto Primera Entrga SOP*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "libro.h"
#include <unistd.h>
#define TAMMENSAJE 10

char mensaje[TAMMENSAJE];
char nombrePS[TAMMENSAJE];

void crearPipe(libro libroSolicitante, char *PipeNombre, int fd){

    int creado=0,fd1, pid;

    //printf("Se abre el pipe para enviar el proceso a receptor, el pipe es %s \n",PipeNombre);
    

    //printf("Se crea el pipe para obtener del receptor una respuesta el pipe es %s \n", libroSolicitante.segundopipe);
   
    /*printf("   \n");
    printf("Se escribe el  pipe %s \n", PipeNombre); 
    printf("Los datos que le llegan al pipe son:\n");
    printf("Operacion : %c\n", libroSolicitante.operacion);
    printf("ISBN : %d\n", libroSolicitante.isbn);
    printf("Nombre : %s\n",libroSolicitante.nombreLibro);
    printf("Pipe : %s\n", libroSolicitante.segundopipe);
    printf("******************************\n");*/
    
    if(write(fd,&libroSolicitante,sizeof(libroSolicitante))==-1){
        perror("Solicitud Erronea");
        exit(0);
    }
    
    //printf("Se logro escribir y se va a realizar la lectura de la respuesta\n");


    creado = 0;
    do { 
        if ((fd1 = open(nombrePS, O_RDONLY)) == -1) {
            perror(" Solicitante  Abriendo el segundo pipe. Se volvera a intentar \n");
            sleep(5);
        } else creado = 1; 
    } while (creado == 0);

   if(read(fd1, mensaje,10)==-1){
       perror("No se logro leer la respuesta del Receptor");
       exit(0);
   } 
   printf("\n");
   printf("\n");
   printf("\n");
   printf("*************El proceso termina #proceso: %s*************\n", nombrePS);

   if(strcmp(mensaje,"1")==0){
       printf("\n");
       
       printf("                        !!La solicitud se realizo con EXITO!!\n" );
       printf("\n");
   }
   
   else if(strcmp(mensaje,"0")==0){
       printf("\n");
       printf("                        !!La solicitud No fue exitosa!!\n");
       printf("\n");
   }
   close(fd1); 
}

void leerArchivo(char *archivo, int *ubiLibro, libro *librosSolicitantes){
    FILE *fd;
   
    fd = fopen(archivo, "r");
    char lineaToken[256];
    char lineaToken2[256];
    while(!feof(fd)){
        fgets(lineaToken, sizeof(lineaToken), fd);
        char *tok;
        tok = strtok(lineaToken, ",");
        librosSolicitantes[*ubiLibro].operacion=tok[0];
        tok = strtok(NULL, ",");
        strcpy(librosSolicitantes[*ubiLibro].nombreLibro,tok);
        tok = strtok(NULL, ",");
        librosSolicitantes[*ubiLibro].isbn = atoi(tok);
        strcpy(librosSolicitantes[*ubiLibro].segundopipe, nombrePS);
        *ubiLibro = *ubiLibro+1;
    }
}


int main(int argc, char *argv[]){
    
    if(argc !=3 && argc != 5){  
        perror("No se pasaron los argumentos necesarios o son argumentos incorrectos\n");
        printf("$ ./solicitante [–i file] –p pipeReceptor  ");
        printf("El [-i file ] es opcional\n");
        exit(0);
    }
    
    libro libroSolicitante;
    int fd;
    int creado=0;
    mode_t fifo_mode = S_IRUSR | S_IWUSR;
    sprintf(nombrePS, "pipePS#%d", getpid());

    unlink(nombrePS);
    if (mkfifo (nombrePS, fifo_mode) == -1) {
        perror("receptor  mkfifo");
        exit(0);
    }

    if(argc == 3){
        do { 
            if ((fd = open(argv[2], O_WRONLY )) == -1) {
                perror("Error en Solicitante al leer el pipe ");
                printf(" Se volvera a intentar despues\n");
                sleep(5);         
            } else creado = 1; 
        }  while (creado == 0);

    }else{
        do { 
            if ((fd = open(argv[4], O_WRONLY )) == -1) {
                perror("Error en Solicitante al leer el pipe ");
                printf(" Se volvera a intentar despues\n");
                sleep(5);         
            } else creado = 1; 
        }  while (creado == 0);

    }

    if(argc==3){
        int operacion;
        do{
            printf("Que operacion va realizar");
            printf("\n");
            printf("1. Devolver Libro\n");
            printf("2. Pedir Libro\n");
            printf("3. Renovar Libro\n");
            printf("4. Salir\n");
            scanf("%d",&operacion);
            printf("Inserte el nombre del libro \n");
            scanf("%s", libroSolicitante.nombreLibro); 
            printf("Digite el ISBN del libro\n");
            scanf("%d",&libroSolicitante.isbn);
            strcpy(libroSolicitante.segundopipe, nombrePS);

            switch (operacion){
                case 1:
                    libroSolicitante.operacion = 'D';
                    break;
                
                case 2:
                    libroSolicitante.operacion = 'P';
                    break;
                
                case 3:
                    libroSolicitante.operacion = 'R';
                    break;
                default:
                    exit(0);
                                                                      
            }
/*
            printf("ISBN : %d\n", libroSolicitante.isbn);
            printf("Nombre : %s\n", libroSolicitante.nombreLibro);
            printf("Operacion : %c\n", libroSolicitante.operacion);
            printf("Pipe : %s\n", libroSolicitante.segundopipe);*/

            crearPipe(libroSolicitante, argv[2], fd);

            
        }while(operacion != 4);
        

    }
    
    if(argc==5){
        libro librosSolicitantes[100];
        int ubiLibro = 0;
        leerArchivo(argv[2], &ubiLibro, librosSolicitantes);
        printf(" \n");
        printf("-----------Se envio la solicitud correspondiente---------");    
        //printf("Solicitudes :\n");

        for(int i=0; i<ubiLibro; i++){
            /*printf(" \n");
            printf(" \n");
            printf("Operacion : %c\n", librosSolicitantes[i].operacion);
            printf("ISBN : %d\n", librosSolicitantes[i].isbn);
            printf("Nombre : %s\n", librosSolicitantes[i].nombreLibro);
            printf("Pipe : %s\n", librosSolicitantes[i].segundopipe);*/
            crearPipe(librosSolicitantes[i],argv[4], fd);
        }
       
    }
    
    close(fd);


    return 0;
}
