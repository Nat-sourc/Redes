#define Tamano 100

typedef  struct libro{  
    char segundopipe[Tamano];  
    char nombreLibro[50];  
    int isbn;  
    char operacion;
} libro;

typedef struct date{
    int dia;
    int mes;
    int anio;
}date;

typedef struct datosBD{
    char operacion;
    int idlibro;
    date fecha;
} datosBD;

typedef struct datosGeneralesBD{
    char nombre[50];
    int isbn;
    int cant;
    datosBD datosBD[Tamano];
}datosGeneralesBD;
